composer install

/// crear la base de datos en xamp con el nombre de cup
php artisan migrate:fresh --seed

php artisan serve