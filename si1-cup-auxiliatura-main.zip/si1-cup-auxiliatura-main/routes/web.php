<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CarreraController;
use Illuminate\Support\Facades\Route;

Route::get('/login',[AuthController::class,'index'])->name('loginIndex');
Route::post('/login',[AuthController::class,'login'])->name('login');


Route::middleware('auth:admin,docente')->get('/dashboard',[AuthController::class,'dashboard'])->name('dashboard');

//un caso de uso
Route::prefix('carrera')->middleware('auth:admin')->group(function () {
    Route::get('/',[CarreraController::class,'index'])->name('carrera.listar');
    Route::post('/',[CarreraController::class,'create'])->name('carrera.crear');
    Route::post('/{id}',[CarreraController::class,'update'])->name('carrera.modificar');
    Route::post('/eliminar',[CarreraController::class,'delete'])->name('carrera.eliminar');
});