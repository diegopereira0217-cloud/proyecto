<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        DB::table('rols')->insert([
            'nombre'=>"administrador"    
        ]);
        DB::table('rols')->insert([
            'nombre'=>"funcionario"    
        ]);
        DB::table('rols')->insert([
            'nombre'=>"docente"    
        ]);
        DB::table('rols')->insert([
            'nombre'=>"alumno"    
        ]);

        DB::table('users')->insert([
            'username' => 'admin',
            'correo' => 'admin@example.com',
            'password' => Hash::make('admin123'), // cambia esta contraseña
            'rol_id' => 1, // Asegúrate que el rol 1 exista en la tabla rols
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
