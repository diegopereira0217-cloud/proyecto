<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body>

    <div class="container">
        <div class="login-box">
            <form method="POST" action="{{route('login')}}" > 
                @csrf  
                <h2>Login Form</h2>
                <div class="input-group">
                    <span class="icon">👤</span>
                    <input type="text" placeholder="Email or Phone" name="username">
                </div>

                <div class="input-group">
                    <span class="icon">🔒</span>
                    <input type="password" placeholder="Password" name="password">
                </div>               

                @error('error')
                    <p>{{ $message }}</p>
                @enderror

                <button type="submit" class="login-btn">Login</button>            
            </form>

        </div>
    </div>

</body>
</html>