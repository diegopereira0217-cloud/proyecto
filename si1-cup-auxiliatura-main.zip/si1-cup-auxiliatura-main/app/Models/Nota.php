<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Nota extends Model
{
    protected $fillable= [
        "nota","materia","porcentaje","ponderado"
    ];
}
