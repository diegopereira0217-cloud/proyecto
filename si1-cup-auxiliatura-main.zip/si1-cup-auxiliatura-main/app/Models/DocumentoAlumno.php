<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentoAlumno extends Model
{
    //
}
