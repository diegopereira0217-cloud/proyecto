<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Postulacion extends Model
{
    protected $fillable= [
        "semestre","anio","alumno_id"
    ];
}
