<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Alumno extends Model
{
    protected $fillable= [
        "nombre","apellido","ci","fecha_nac","genero","user_id"
    ];


}
