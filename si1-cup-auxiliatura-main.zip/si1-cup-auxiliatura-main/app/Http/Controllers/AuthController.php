<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function index(){
        return view('auth.index');
    }

    public function dashboard(){
        return view('dashboard');
    }

    public function login(Request $request){
         
        $validate = $request->validate([
            "username" => 'required',
            'password' => 'required'
        ]);
        $user = User::where('username', $request->username)->first();
        if($user){ 
            $rol = $user->rol_id;
           
            switch ($rol) {
                case '1':
                    $guard = "admin";
                    break;
                case '2':
                    $guard = "funcionario";
                    break;
                case '3':
                    $guard = "docente";
                    break;
                case '4':
                    $guard = "estudiante";
                    break;
                
                default:
                    $guard = "web";
                    break;
            }
            

            if(auth()->guard($guard)->attempt($validate)){
                $request->session()->regenerate();
                //dd(auth()->guard($guard)->user()->username);
                return redirect()->route('dashboard');
            }
            else{
                return back()->withErrors(['error'=>'contraseña incorrecta']);
            }
            

        }
        else{
            return back()->withErrors(['error'=>'usuario incorrecto']);
        }

        

    }
}
